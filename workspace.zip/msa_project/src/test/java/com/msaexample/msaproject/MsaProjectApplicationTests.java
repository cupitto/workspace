package com.msaexample.msaproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsaProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}

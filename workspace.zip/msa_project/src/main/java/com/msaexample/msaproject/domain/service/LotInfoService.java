package com.msaexample.msaproject.domain.service;

import java.util.List;

import com.msaexample.msaproject.domain.model.TnLotInfo;

public interface LotInfoService {

	public String createLotInfo(List<TnLotInfo> lotInfoList);

}
